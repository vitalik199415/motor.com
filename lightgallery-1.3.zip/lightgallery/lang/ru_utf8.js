try{
	lightgallery.setLangVars({
		next	: 'Вперед',
		prev	: 'Назад',
		zoomIn	: 'Увеличить',
		zoomOut	: 'Уменьшить',
		fullSize: 'Реальный размер',
		fitScreen: 'По размеру экрана',
		close	: 'Закрыть',
		image	: 'Изображение',
		of		: 'из'
	})
}catch(e){}
